import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:nasa_space_images/api/nasa_api.dart';
import 'package:nasa_space_images/models/apod_model.dart';

// StateNotifier to manage fetching APOD images
final apodControllerProvider =
    StateNotifierProvider<ApodController, AsyncValue<List<ApodModel>>>(
  (ref) => ApodController(nasaApi: ref.read(NASAApiProvider)),
);

class ApodController extends StateNotifier<AsyncValue<List<ApodModel>>> {
  final NASAApi _nasaApi;
  ApodController({required NASAApi nasaApi})
      : _nasaApi = nasaApi,
        super(const AsyncValue.data([]));

  // Fetches 10 images from NASA's API
  Future<void> fetchTenImages(BuildContext context) async {
    state = const AsyncValue.loading(); // Set state to loading
    try {
      List<ApodModel> apodList = [];
      for (int i = 1; i <= 10; i++) {
        final date = DateFormat('yyyy-MM-dd')
            .format(DateTime.now().subtract(Duration(days: i)));
        final apod = await _nasaApi.fetchPicture(date);
        if (apod != null) {
          apodList.add(apod);
        }
      }
      state = AsyncValue.data(apodList); // Update state with fetched data
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace); // Handle any error
    }
  }
}
