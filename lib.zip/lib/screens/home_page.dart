import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nasa_space_images/controller/apod_controller.dart';

class HomePage extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Watch the APOD controller provider
    final apodState = ref.watch(apodControllerProvider);

    return Scaffold(
      appBar: AppBar(title: Text('NASA APOD Images')),
      body: apodState.when(
        data: (apodList) {
          // Data loaded successfully, display list of images
          return ListView.builder(
            itemCount: apodList.length,
            itemBuilder: (context, index) {
              final apod = apodList[index];
              if (apod.media_type == "image") {
                return ListTile(
                  title: Text(apod.title!),
                  subtitle: Text(apod.date!),
                  leading:
                      Image.network(apod.url!, width: 100, fit: BoxFit.cover),
                  isThreeLine: true,
                );
              }
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) =>
            Center(child: Text('Error: ${error.toString()}')),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Trigger the fetch of the APOD images
          ref.read(apodControllerProvider.notifier).fetchTenImages(context);
        },
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
