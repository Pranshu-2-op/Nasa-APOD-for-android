class apod_model {
  String? title;
  String? url;
  String? explaination;
  String? date;
}
