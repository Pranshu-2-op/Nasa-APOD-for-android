import 'package:flutter/material.dart';

class NasaLoader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/loader.gif', // Path to your GIF file in the assets folder
      width: 100,
      height: 100,
    );
  }
}
