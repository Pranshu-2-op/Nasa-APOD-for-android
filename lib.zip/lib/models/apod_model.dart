// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class ApodModel {
  String? title;
  String? url;
  String? description;
  String? date;
  String? media_type;
  ApodModel({
    this.title,
    this.url,
    this.description,
    this.date,
    this.media_type,
  });

  ApodModel copyWith({
    String? title,
    String? url,
    String? description,
    String? date,
    String? media_type,
  }) {
    return ApodModel(
      title: title ?? this.title,
      url: url ?? this.url,
      description: description ?? this.description,
      date: date ?? this.date,
      media_type: media_type ?? this.media_type,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'title': title,
      'url': url,
      'description': description,
      'date': date,
      'media_type': media_type,
    };
  }

  factory ApodModel.fromMap(Map<String, dynamic> map) {
    return ApodModel(
      title: map['title'] != null ? map['title'] as String : null,
      url: map['url'] != null ? map['url'] as String : null,
      description:
          map['description'] != null ? map['description'] as String : null,
      date: map['date'] != null ? map['date'] as String : null,
      media_type:
          map['media_type'] != null ? map['media_type'] as String : null,
    );
  }

  String toJson() => json.encode(toMap());

  // Corrected factory constructor
  factory ApodModel.fromJson(Map<String, dynamic> source) =>
      ApodModel.fromMap(source);

  @override
  String toString() {
    return 'ApodModel(title: $title, url: $url, description: $description, date: $date, media_type: $media_type)';
  }

  @override
  bool operator ==(covariant ApodModel other) {
    if (identical(this, other)) return true;

    return other.title == title &&
        other.url == url &&
        other.description == description &&
        other.date == date &&
        other.media_type == media_type;
  }

  @override
  int get hashCode {
    return title.hashCode ^
        url.hashCode ^
        description.hashCode ^
        date.hashCode ^
        media_type.hashCode;
  }
}
