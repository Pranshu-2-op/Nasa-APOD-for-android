import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'package:nasa_space_images/models/apod_model.dart';

final NASAApiProvider = Provider(
  (ref) => NASAApi(),
);

class NASAApi {
  static const String _apiKey = 'E184FVwWqSEGkcWyFFOsYjDxR0d07hOxhT6z9GxC';

  Future<ApodModel?> fetchPicture(String date) async {
    final url =
        'https://api.nasa.gov/planetary/apod?api_key=$_apiKey&date=$date';
    final response = await http.get(Uri.parse(url));
    print(response);
    if (response.statusCode == 200) {
      return ApodModel.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Failed to load image');
    }
  }
}
